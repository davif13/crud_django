from django.contrib import admin

from places.models import Places

admin.site.register(Places)